#include<bits/stdc++.h>
using namespace std;
 
#define sd(mark) scanf("%d",&mark)
#define ss(mark) scanf("%s",&mark)
#define sl(mark) scanf("%lld",&mark)
#define debug(mark) printf("check%d\n",mark)
#define clr(mark) memset(mark,0,sizeof(mark))
#define F first
#define S second
#define MP make_pair
#define PB push_back
#define ll long long
#define mod 1000000007
char s[1010];
bool check(int i,int l)
{
	if(i<0||i>=l)
		return 0;
	return 1;
}
int main()
{
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);

	int t,tt,i,l;
	sd(t);
	for(tt=1;tt<=t;++tt)
	{
		ss(s);
		l=strlen(s);
		ll p=1;
		for(i=0;i<l;++i)
		{
			int c=0;
			map<char,int> mapp;
			mapp[s[i]]=1;
			if(check(i-1,l))
				mapp[s[i-1]]=1;
			if(check(i+1,l))
				mapp[s[i+1]]=1;
			for(auto it=mapp.begin();it!=mapp.end();it++)
				c++;
			p=(p*c)%mod;
		}
		printf("Case #%d: %lld\n",tt,p);
	}
}